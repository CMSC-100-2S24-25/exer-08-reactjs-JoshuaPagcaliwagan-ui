//Joshua O. Pagcaliwagan CMSC 100 C-1L Exer8 JSReact Part 1
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
