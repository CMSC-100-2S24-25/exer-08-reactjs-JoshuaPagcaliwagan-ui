//Joshua O. Pagcaliwagan CMSC 100 C-1L Exer8 JSReact Part 1
//import needed things
import Header from './components/Header.jsx'
import Item from './components/Item.jsx'
import './App.css'

function App() {
  const items = [ //array of items, names, url, and id
    { name: 'Asahy Power Juicer', url: "#", id:1, image:"./public/a.jpg"},
    { name: 'Samsong Washing Machine', url: "#", id:2, image:'./public/b.jpg'},
    { name: 'Hanabesh Electric Fan', url: "#", id:3, image:'./public/c.jpg'},
    { name: 'Appol Smartphone', url: "#", id:4, image:'./public/d.jpg'},
  ]

    return(//div designs, font, display, wrap,
      <div style={{ fontFamily: 'Arial', backgroundColor: '#FF69B4'}}> 
        <Header />
        <div style={{ display: 'flex', flexWrap: 'wrap', padding: '20px', gap:'20px' }}>
          {
            items.map(item => (<Item key={item.id} name={item.name} image={item.image} /> //to map/get each item
            ))
            }
        </div>
      </div>
    )
  }
export default App//export 