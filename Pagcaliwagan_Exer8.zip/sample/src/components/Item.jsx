//Joshua O. Pagcaliwagan CMSC 100 C-1L Exer8 JSReact Part 1
function Item(props) {
    function Add() {//function to add (tho it will only console.log)
        console.log(`Added ${props.name} to the cart!`)
        }
    return (//div design, width, height, bgcolors, margin, padding, textAlign, also button onclick calls the add function (console.log)
        <div style={{ width: '150px', backgroundColor: '#FFC0CB', padding: '10px', textAlign: 'center', color:'black'}}>
            <div style={{ height: '100px', marginBottom: '10px' }}>
                <img src={props.image} style={{ width: '100%', height: '100%', objectFit: 'cover'}} />
            </div>
            <button onClick={Add} style={{ backgroundColor: '#FF00BF', marginBottom: '10px' }}>
                Add to cart
            </button>
        </div>
    )
}

export default Item//export function