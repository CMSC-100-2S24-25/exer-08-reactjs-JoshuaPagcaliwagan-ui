//Joshua O. Pagcaliwagan CMSC 100 C-1L Exer8 JSReact Part 1
function Button(props){
    return(//anchor tag with # so page would refresh, props.name so that the list of menus would appear
        <a href="#" style={{ color: 'black' }}>
            {props.name}
        </a>
    )
}

export default Button//export function