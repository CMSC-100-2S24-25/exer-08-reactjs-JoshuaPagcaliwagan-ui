//Joshua O. Pagcaliwagan CMSC 100 C-1L Exer8 JSReact Part 1
import Button from './Button.jsx'

function Header(){
    const menus = [//array of menus, name, url, id
        { name: 'Appliances', url:'#', id: 1},
        { name: 'Gadgets', url:'#', id: 2},
        { name: 'Accessories', url:'#', id: 3},
        ];

        return(//div design for header, map menus array to display all menus
            <div style={{ display: 'flex', backgroundColor: '#FF00FF', padding: '10px', justifyContent: 'space-between'}}>
                <div style={{ fontWeight: 'bold', paddingLeft: '20px'}}>Lazado: Araw-araw Kang Panalo!</div>
                <div style={{ display: 'flex', gap: '20px', paddingRight: '20px' }}>
                {menus.map(menu => <Button key={menu.id} name={menu.name} />)}
                </div>
            </div>
        )
    }

export default Header//export function